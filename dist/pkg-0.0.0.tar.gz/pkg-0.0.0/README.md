# revenue-sharing
Generalized revenue sharing cadCAD model
